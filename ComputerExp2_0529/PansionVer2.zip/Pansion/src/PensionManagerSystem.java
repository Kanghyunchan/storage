import java.util.InputMismatchException;
import java.util.Scanner;

public class PensionManagerSystem {

    public static int inputInt(Scanner input) {
        System.out.print(">>> ");
        return input.nextInt();
    }

    public static void customerMenu(CustomerManager customerManager) {
        Scanner input = new Scanner(System.in);
        int select = 0;

        System.out.println("고객관리메뉴");

        while (select != 5) {
            try {
                System.out.println("원하는 기능의 번호를 입력해주세요. (1.고객등록, 2.고객검색, 3.고객 정보 수정, 4.고객 정보 삭제, 5.뒤로가기)");
                select = PensionManagerSystem.inputInt(input);
                switch (select) {
                    case 1:
                        System.out.print("등록하실 고객의 ID를 입력해주세요: ");
                        String id = input.next();
                        if (customerManager.findById(id) != null) {
                            System.out.println("ID 중복입니다.");
                        } else {
                            input = new Scanner(System.in);
                            System.out
                                    .print("사용가능한 ID입니다. 이름, 전화번호, 이메일을 입력해주세요(양식. 홍길동, 010-1234-5678, hong@naver.com): ");
                            String str = input.nextLine();
                            Customer temp = new Customer(null, null, null, null);
                            if (temp.fromString(id.concat("," + str)) != null) {
                                customerManager.addCustomer(temp.fromString(id.concat("," + str)));
                                System.out.println("고객등록 완료되었습니다.");
                            } else {
                                System.out.println("고객등록 실패했습니다.");
                            }
                        }
                        break;
                    case 2:
                        System.out.println("1.전체검색, 2.ID검색, 3.뒤로가기");
                        select = PensionManagerSystem.inputInt(input);
                        switch (select) {
                            case 1:
                                System.out.println("모든 고객의 정보를 출력합니다.");
                                customerManager.listCustomers();
                                break;
                            case 2:
                                System.out.println("검색할 고객의 ID를 입력해주세요.");
                                select = PensionManagerSystem.inputInt(input);
                                if (customerManager.findById(String.valueOf(select)) != null) {
                                    System.out.println(customerManager.findById(String.valueOf(select)).toString(false));
                                } else {
                                    System.out.println("해당 " + select + "ID의 고객은 존재하지 않습니다.");
                                }
                                break;
                            case 3:
                                System.out.println("이전 메뉴로 이동합니다.");
                                break;
                            default:
                                System.out.println("입력이 잘못되었습니다.");
                        }
                        break;
                    case 3:
                        System.out.println("수정할 고객의 ID를 입력해주세요");
                        select = PensionManagerSystem.inputInt(input);
                        if (customerManager.findById(String.valueOf(select)) != null) {
                            input = new Scanner(System.in);
                            System.out.println("수정할 정보를 입력해주세요(양식. 이름, 전화번호, 이메일): ");
                            System.out.print(">>> ");
                            String updateStr = input.nextLine();
                            customerManager.updateById(String.valueOf(select), updateStr);
                        } else {
                            System.out.println("해당 " + select + "ID의 고객은 존재하지 않습니다.");
                        }
                        break;
                    case 4:
                        System.out.println("삭제할 고객의 ID를 입력해주세요");
                        select = PensionManagerSystem.inputInt(input);
                        if (customerManager.findById(String.valueOf(select)) != null) {
                            input = new Scanner(System.in);
                            System.out.println("정말로 삭제하시겠습니까?(삭제를 원하면 YES를 입력해주세요)");
                            System.out.print(">>> ");
                            String ask = input.next();
                            if (ask.equals("YES")) {
                                if (customerManager.deleteById(String.valueOf(select))) {
                                    System.out.println("고객 정보 삭제 성공했습니다.");
                                } else {
                                    System.out.println("고객 정보 삭제 실패했습니다.");
                                }

                            } else {
                                System.out.println("삭제를 취소하였습니다.");
                            }
                        } else {
                            System.out.println("해당 " + select + "ID의 고객은 존재하지 않습니다.");
                        }
                        break;
                    case 5:
                        System.out.println("이전 메뉴로 이동합니다.");
                        break;
                    default:
                        System.out.println("입력이 잘못되었습니다.");
                }

            } catch (InputMismatchException e) {
                System.out.println("입력이 잘못되었습니다.");
                input = new Scanner(System.in);
            }
        }
    }

    public static void roomMenu(RoomManager roomManager) {
        Scanner input = new Scanner(System.in);
        int select = 0;

        System.out.println("객실관리메뉴");

        while (select != 5) {
            try {
                System.out.println("원하는 기능의 번호를 입력해주세요. (1.객실등록, 2.객실검색, 3.객실 정보 수정, 4.객실 삭제, 5.뒤로가기)");
                select = PensionManagerSystem.inputInt(input);
                switch (select) {
                    case 1:
                        System.out.print("등록하실 객실의 ID를 입력해주세요: ");
                        String id = input.next();
                        if (roomManager.findById(id) != null) {
                            System.out.println("ID 중복입니다.");
                        } else {
                            input = new Scanner(System.in);
                            System.out
                                    .print("사용가능한 ID입니다. 객실타입, 요금, 인원수, 설명을 입력해주세요(양식. 작은방, 30000, 4, 풍경이 잘 보이는 방): ");
                            String str = input.nextLine();
                            Room temp = new Room(null, null, 0, 0, null);
                            if (temp.fromString(id.concat("," + str)) != null) {
                                roomManager.addRoom(temp.fromString(id.concat("," + str)));
                                System.out.println("객실등록 완료되었습니다.");
                            } else {
                                System.out.println("객실등록 실패했습니다.");
                            }
                        }
                        break;
                    case 2:
                        System.out.println("1.전체검색, 2.ID검색, 3.뒤로가기");
                        select = PensionManagerSystem.inputInt(input);
                        switch (select) {
                            case 1:
                                System.out.println("모든 객실의 정보를 출력합니다.");
                                roomManager.listRooms();
                                break;
                            case 2:
                                System.out.println("검색할 객실의 ID를 입력해주세요.");
                                select = PensionManagerSystem.inputInt(input);
                                if (roomManager.findById(String.valueOf(select)) != null) {
                                    System.out.println(roomManager.findById(String.valueOf(select)).toString(false));
                                } else {
                                    System.out.println("해당 " + select + "ID의 객실은 존재하지 않습니다.");
                                }
                                break;
                            case 3:
                                System.out.println("이전 메뉴로 이동합니다.");
                                break;
                            default:
                                System.out.println("입력이 잘못되었습니다.");
                        }
                        break;
                    case 3:
                        System.out.println("수정할 객실의 ID를 입력해주세요");
                        select = PensionManagerSystem.inputInt(input);
                        if (roomManager.findById(String.valueOf(select)) != null) {
                            input = new Scanner(System.in);
                            System.out.println("수정할 정보를 입력해주세요(양식. 요금, 인원수, 설명): ");
                            System.out.print(">>> ");
                            String updateStr = input.nextLine();
                            roomManager.updateById(String.valueOf(select), updateStr);
                        } else {
                            System.out.println("해당 " + select + "ID의 객실은 존재하지 않습니다.");
                        }
                        break;
                    case 4:
                        System.out.println("삭제할 객실의 ID를 입력해주세요");
                        select = PensionManagerSystem.inputInt(input);
                        if (roomManager.findById(String.valueOf(select)) != null) {
                            input = new Scanner(System.in);
                            System.out.println("정말로 삭제하시겠습니까?(삭제를 원하면 YES를 입력해주세요)");
                            System.out.print(">>> ");
                            String ask = input.next();
                            if (ask.equals("YES")) {
                                if (roomManager.deleteById(String.valueOf(select))) {
                                    System.out.println("객실 삭제 성공했습니다.");
                                } else {
                                    System.out.println("객실 삭제 실패했습니다.");
                                }

                            } else {
                                System.out.println("삭제를 취소하였습니다.");
                            }
                        } else {
                            System.out.println("해당 " + select + "ID의 객실은 존재하지 않습니다.");
                        }
                        break;
                    case 5:
                        System.out.println("이전 메뉴로 이동합니다.");
                        break;
                    default:
                        System.out.println("입력이 잘못되었습니다.");
                }

            } catch (InputMismatchException e) {
                System.out.println("입력이 잘못되었습니다.");
                input = new Scanner(System.in);
            }
        }
    }

    public static void reservationMenu() {

    }

    public static void main(String[] args) {
        CustomerManager customManager = new CustomerManager();
        RoomManager roomManager = new RoomManager();
        ReservationManager reservationManager = new ReservationManager();
        SystemFileManager fileManager = new SystemFileManager(customManager, roomManager, reservationManager);

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            fileManager.saveToFile();
        }));

        int select;
        boolean isLoop = true;
        Scanner input = new Scanner(System.in);
        fileManager.loadFromFile();
        System.out.println("펜션관리시스템");

        while (isLoop) {
            try {
                System.out.println("원하는 기능의 번호를 입력해주세요. (1.고객관리, 2.객실관리, 3.예약관리, 4.시스템종료)");
                select = PensionManagerSystem.inputInt(input);

                switch (select) {
                    case 1:
                        customerMenu(customManager);
                        break;
                    case 2:
                        roomMenu(roomManager);
                        break;
                    case 3:
                        reservationMenu();
                        break;
                    case 4:
                        isLoop = false;
                        input.close();
                        //fileManager.saveToFile();
                        break;
                    default:
                        System.out.println("입력이 잘못되었습니다.");
                }
            } catch (InputMismatchException e) {
                System.out.println("입력이 잘못되었습니다.");
                input = new Scanner(System.in);
            }
        }
    }
}
