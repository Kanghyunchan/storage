import java.util.ArrayList;

public class CustomerManager {
	private ArrayList<Customer> customers = new ArrayList<>();

	public void addCustomer(Customer c) {
		customers.add(c);
		System.out.println("고객등록 완료되었습니다.");
	}

	public void listCustomers() {
		for (Customer c : customers) {
			System.out.println(c.toString());
		}
	}

}
