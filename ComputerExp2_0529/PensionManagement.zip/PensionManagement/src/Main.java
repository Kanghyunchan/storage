public class Main {
	public static void main(String[] args) {
		FileManager fm = new FileManager();
		fm.fileCreate("Customers");
		fm.fileRead("Customers");
	}
}
