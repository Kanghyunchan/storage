import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileManager {
	public void fileCreate(String fileName) {
		File f = new File(fileName + ".txt");
		boolean isCreated = (f.exists()) ? true : false;
		try {
			FileWriter fileWirte = new FileWriter(fileName + ".txt", isCreated);
			// fileWirte.write("asdasds\n adwqdv");
			fileWirte.close();
		} catch (IOException e) {
			System.out.println("파일 생성 에러");
		}
	}

	public void fileRead(String fileName) {
		try {
			FileReader fileRead = new FileReader(fileName + ".txt");
			int data = 0;
			if (fileRead != null) {
				while ((data = fileRead.read()) != -1) {
					System.out.print((char) data);
				}
				fileRead.close();
			}
		} catch (IOException e) {

		}
	}
}
