public class Customer {
	private String customerId, name, phone, email;

	public Customer(String customrId, String name, String phone, String email) {
		this.customerId = customrId;
		this.name = name;
		this.phone = phone;
		this.email = email;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String toString() {
		return "ID: " + customerId + " 이름: " + name + " 전화번호: " + phone + " 이메일: " + email;
	}

	public Customer fromString(String str) {
		String[] cut = str.replace(" ", "").split(",");
		if (cut.length != 3) {
			System.out.println("입력값 에러");
			return null;
		} else {
			return new Customer(cut[0], cut[1], cut[2], cut[3]);
		}
	}
}
